import { useRef, useState } from "react";

export default function Home() {
  const registerRef = useRef(null);
  const contactRef = useRef(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);

  const scrollToSection = (ref) => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("https://formspree.io/f/xyyrrnnp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          message: formData.message,
        }),
      });
      if (response.ok) {
        setSubmitted(true);
        setFormData({ name: "", email: "", phone: "", message: "" });
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-yellow-500 text-white py-20 text-center">
        <h1 className="text-5xl font-bold mb-4">Powering Players Beyond the Pitch</h1>
        <p className="text-xl mb-6">Full-service player management: Contracts. Performance. Endorsements.</p>
        <div className="space-x-4">
          <button onClick={() => scrollToSection(registerRef)} className="bg-white text-blue-900 font-bold py-2 px-4 rounded">Get Represented</button>
          <button onClick={() => scrollToSection(contactRef)} className="border border-white py-2 px-4 rounded">Contact Us</button>
        </div>
      </section>
      {/* Additional Sections Here */}
    </div>
  );
}